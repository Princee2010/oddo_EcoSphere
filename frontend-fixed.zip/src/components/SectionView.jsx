const SECTIONS = {
  environmental: {
    title: 'Environmental',
    blurb: 'Emissions, energy, water, and waste diversion tracked by site.',
    columns: ['Metric', 'This period', 'Target', 'Status'],
    rows: [
      ['Scope 1 emissions', '1,240 tCO2e', '1,100 tCO2e', 'Off track'],
      ['Scope 2 emissions', '3,860 tCO2e', '3,900 tCO2e', 'On track'],
      ['Renewable energy mix', '61%', '75%', 'Off track'],
      ['Water withdrawal', '48,200 m³', '50,000 m³', 'On track'],
      ['Waste diverted from landfill', '72%', '80%', 'Off track'],
    ],
  },
  social: {
    title: 'Social',
    blurb: 'Labor practices, community investment, and supply-chain conditions.',
    columns: ['Metric', 'This period', 'Target', 'Status'],
    rows: [
      ['Employee turnover', '9.4%', '<10%', 'On track'],
      ['Gender pay gap', '3.1%', '0%', 'Off track'],
      ['Safety incidents', '2', '0', 'Off track'],
      ['Community investment', '$412,000', '$400,000', 'On track'],
      ['Supplier code-of-conduct coverage', '88%', '100%', 'Off track'],
    ],
  },
  policies: {
    title: 'Policies',
    blurb: 'Governance documents that keep disclosures defensible.',
    columns: ['Policy', 'Owner', 'Last reviewed', 'Status'],
    rows: [
      ['Code of ethics', 'Legal', 'Feb 2026', 'Current'],
      ['Anti-bribery & corruption', 'Compliance', 'Jan 2026', 'Current'],
      ['Whistleblower policy', 'HR', 'Mar 2025', 'Review due'],
      ['Data privacy policy', 'IT', 'Apr 2026', 'Current'],
      ['Supplier code of conduct', 'Procurement', 'Nov 2025', 'Review due'],
    ],
  },
  compliance: {
    title: 'Compliance',
    blurb: 'Reporting framework status across CSRD, GRI, TCFD, and SASB.',
    columns: ['Framework', 'Status', 'Last updated'],
    rows: [
      ['CSRD', 'Compliant', 'Jun 18, 2026'],
      ['GRI', 'Compliant', 'Jun 18, 2026'],
      ['TCFD', 'In progress', 'May 30, 2026'],
      ['SASB', 'Not started', '—'],
    ],
  },
  'risk-register': {
    title: 'Risk register',
    blurb: 'Open ESG-related risks and their mitigation owners.',
    columns: ['Risk', 'Severity', 'Owner', 'Status'],
    rows: [
      ['Carbon pricing exposure', 'High', 'Finance', 'Mitigating'],
      ['Supply-chain labor violation', 'High', 'Procurement', 'Investigating'],
      ['Water scarcity at Site 4', 'Medium', 'Operations', 'Monitoring'],
      ['Board diversity shortfall', 'Medium', 'HR', 'Mitigating'],
      ['Data breach (ESG records)', 'Low', 'IT', 'Monitoring'],
    ],
  },
  audits: {
    title: 'Audits',
    blurb: 'Internal and third-party audits of ESG data and controls.',
    columns: ['Audit', 'Auditor', 'Date', 'Outcome'],
    rows: [
      ['FY25 emissions assurance', 'Deloitte', 'Mar 2026', 'Passed'],
      ['Supply-chain labor audit', 'Internal', 'Jan 2026', 'Findings issued'],
      ['Governance controls review', 'KPMG', 'Nov 2025', 'Passed'],
      ['Data quality audit', 'Internal', 'Jun 2026', 'Scheduled'],
    ],
  },
  reports: {
    title: 'Reports',
    blurb: 'Generated disclosures ready for distribution or filing.',
    columns: ['Report', 'Framework', 'Period', 'Status'],
    rows: [
      ['Annual sustainability report', 'GRI', 'FY 2025', 'Published'],
      ['CSRD disclosure package', 'CSRD', 'FY 2025', 'Draft'],
      ['Climate risk report', 'TCFD', 'FY 2025', 'In review'],
      ['Board ESG summary', 'Internal', 'Q2 2026', 'Published'],
    ],
  },
  'team-directory': {
    title: 'Team directory',
    blurb: 'People responsible for ESG data and reporting.',
    columns: ['Name', 'Role', 'Department', 'Email'],
    rows: [
      ['Jordan Silva', 'ESG Lead', 'Sustainability', 'jordan@ecosphere.io'],
      ['Priya Nair', 'Data Analyst', 'Sustainability', 'priya@ecosphere.io'],
      ['Marcus Lee', 'Compliance Officer', 'Legal', 'marcus@ecosphere.io'],
      ['Ana Torres', 'Reporting Manager', 'Finance', 'ana@ecosphere.io'],
    ],
  },
  departments: {
    title: 'Departments',
    blurb: 'Departments contributing ESG data, and their coverage.',
    columns: ['Department', 'Data owner', 'Metrics tracked', 'Completion'],
    rows: [
      ['Operations', 'Ana Torres', '42', '91%'],
      ['Procurement', 'Marcus Lee', '18', '76%'],
      ['HR', 'Priya Nair', '24', '88%'],
      ['Finance', 'Jordan Silva', '12', '100%'],
    ],
  },
}

/**
 * Renders a titled, tabular placeholder view for any dashboard sidebar
 * section that isn't the main Overview. Keeps every section visually
 * consistent with the rest of the app (rounded-2xl cards, mono labels).
 */
function SectionView({ section }) {
  const data = SECTIONS[section]

  if (!data) {
    return (
      <div className="rounded-2xl border border-black/10 bg-offwhite p-8 text-sm text-muted">
        No content configured for “{section}” yet.
      </div>
    )
  }

  return (
    <div>
      <div className="mb-8">
        <span className="font-mono text-xs uppercase tracking-widest text-muted">
          {data.title} · FY 2026
        </span>
        <h1 className="mt-2 font-display text-3xl font-medium text-text">
          {data.title}
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">{data.blurb}</p>
      </div>

      <div className="overflow-hidden rounded-2xl border border-black/10">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-black/10 bg-offwhite">
              {data.columns.map((col) => (
                <th
                  key={col}
                  className="px-5 py-3 font-mono text-xs uppercase tracking-widest text-muted"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.map((row, i) => (
              <tr
                key={row[0]}
                className={i !== data.rows.length - 1 ? 'border-b border-black/10' : ''}
              >
                {row.map((cell, j) => (
                  <td
                    key={j}
                    className={`px-5 py-4 text-sm ${
                      j === 0 ? 'font-medium text-text' : 'font-mono text-muted'
                    }`}
                  >
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default SectionView
